package com.example.telemedicine_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DoctorLogin extends AppCompatActivity {
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");
    private TextView SignUpDoctor;
    private EditText phoneEditText;
    private EditText passwordEditText;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login);

        SignUpDoctor = findViewById(R.id.SignUpDoctor);

        phoneEditText = findViewById(R.id.DoctPhoneNumber);
        passwordEditText = findViewById(R.id.AccountPassword);
        progressBar = findViewById(R.id.progressbar);

        Button loginButton = findViewById(R.id.Login);
        TextView signUpTextView = findViewById(R.id.SignUpDoctor);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        SignUpDoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(DoctorLogin.this, DoctorSignUp.class);
                startActivity(intent);
                finish();
            }
        });

    }

    private void login() {
        String phoneNumber = phoneEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (phoneNumber.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
            return;
        } else {


            // Validate phoneNumber (numbers only)
            if (!phoneNumber.matches("^[0-9]+$")) {
                Toast.makeText(getApplicationContext(), "Phone number can only contain numbers", Toast.LENGTH_SHORT).show();
                return;
            }
            // Perform custom login logic here (e.g., check against a local database or your server).

            databaseReference.child("doctors").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    if(snapshot.hasChild(phoneNumber)){

                        String getPassword =  snapshot.child(phoneNumber).child("password").getValue(String.class);
                        String getSpeciality=  snapshot.child(phoneNumber).child("speciality").getValue(String.class);
                        String getDoctorName =  snapshot.child(phoneNumber).child("name").getValue(String.class);
                        // Save the speciality to SharedPreferences
                        SharedPreferences sharedPreferences = getSharedPreferences("DoctorPrefs", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("doctorSpeciality", getSpeciality);
                        editor.putString("doctorName", getDoctorName);
                        editor.apply();
                        if(getPassword.equals(password)){

                            Toast.makeText(DoctorLogin.this, "Successfully Logged IN", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(DoctorLogin.this, HomeScreenDoctor.class));
                            finish();
                        }else{

                            Toast.makeText(DoctorLogin.this, "Password or phone number wrong", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
    }
}