package com.example.telemedicine_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HomeScreenDoctor extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private ActionBar actionBar;
    private static final String TAG = "AppointmentsActivity"; // Tag for logging

    private ListView appointmentsListView;

    private WebView webView;
    private List<String> appointmentsList;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen_doctor);
   //Initialize your WebView
                webView = findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        //Navigation ui  codes
        Toolbar toolbar = findViewById(R.id.toolbar);
        // Set the initial title of the Toolbar
        toolbar.setTitle("Doctor");
        setSupportActionBar(toolbar);
        // Get the ActionBar and enable the navigation drawer icon
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.icons_menu); // Replace with your icon resource
        }

        drawerLayout = findViewById(R.id.drawer_layout);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        // Inflate the header layout
        View headerView = navigationView.getHeaderView(0);

        // Initialize Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("appointments");

        // Initialize ListView
        appointmentsListView = findViewById(R.id.appointmentsListView);
        SharedPreferences sharedPreferences = getSharedPreferences("DoctorPrefs", MODE_PRIVATE);
        // Retrieve the data using the key
        String doctorSpeciality = sharedPreferences.getString("doctorSpeciality", "");
        // Query for appointments with selectedSpeciality = "General Practitioner"
        Query query = databaseReference.orderByChild("selectedSpeciality").equalTo(doctorSpeciality);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<String> appointmentsList = new ArrayList<>();
                for (DataSnapshot appointmentSnapshot : dataSnapshot.getChildren()) {
                    Map<String, Object> appointmentData = (Map<String, Object>) appointmentSnapshot.getValue();

                    // Check if appointment data is not null
                    if (appointmentData != null) {
                        String appointmentDetails = "Patient Name: " + appointmentData.get("patientName") + "\n" +
                                "Contact Number: " + appointmentData.get("contactNumber") + "\n" +
                                "Appointment Date: " + appointmentData.get("preferredDate") + "\n" +
                                "Appointment Time: " + appointmentData.get("preferredTime") + "\n" +
                                "Speciality: " + appointmentData.get("selectedSpeciality");
                        appointmentsList.add(appointmentDetails);
                    }
                }

                // Create the adapter to populate the ListView
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        HomeScreenDoctor.this,
                        android.R.layout.simple_list_item_1,
                        appointmentsList
                );

                // Set the adapter for the ListView
                appointmentsListView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
                Log.e(TAG, "Database Error: " + databaseError.getMessage());
            }
        });
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.nav_home) {
            Intent intent = new Intent(HomeScreenDoctor.this, HomeScreenDoctor.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
        }  else if (itemId == R.id.share_links) {

            Intent itemScreen = new Intent(HomeScreenDoctor.this, ShareLinkToPatient.class);
            itemScreen.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(itemScreen);

        }else if (itemId == R.id.nav_your_appointments) {

            Intent itemScreen = new Intent(HomeScreenDoctor.this, AppointmentDoctor.class);
            itemScreen.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(itemScreen);
        }else if (itemId == R.id.nav_your_links) {

            Intent itemScreen = new Intent(HomeScreenDoctor.this, VideoConferenceLinkDoctor.class);
            itemScreen.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(itemScreen);


        }else if (itemId == R.id. report_view_links) {

            Intent itemScreen = new Intent(HomeScreenDoctor.this, DoctorReportView.class);
            itemScreen.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(itemScreen);
        }else if (itemId == R.id.report_links) {

            Intent itemScreen = new Intent(HomeScreenDoctor.this, SubmitConsultationReport.class);
            itemScreen.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(itemScreen);
        }else if (itemId == R.id.nav_join_video) {
            // Show the WebView
            webView.setVisibility(View.VISIBLE);
            // Load the web page you want (e.g., a video conferencing website)
            webView.loadUrl("https://kontapro.online/face-time/index.html");
        } else if (itemId == R.id.nav_sign_out) {
            clearUserDataFromSharedPreferences();
            navigateToLoginScreen();

        }

        // Close the drawer after handling the item
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
    private void clearUserDataFromSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserData", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }

    private void navigateToLoginScreen() {
        Intent intent = new Intent(this, PatientLoginActivity.class);
        startActivity(intent);
        finish();
    }
}
