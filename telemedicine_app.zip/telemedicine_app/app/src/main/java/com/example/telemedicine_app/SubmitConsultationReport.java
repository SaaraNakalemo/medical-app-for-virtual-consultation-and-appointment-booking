package com.example.telemedicine_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SubmitConsultationReport extends AppCompatActivity {

    private EditText patientNameEditText;
    private EditText consultationReportEditText;
    private Button submitReportButton;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_consultation_report);

                patientNameEditText = findViewById(R.id.patientNameEditText);
        consultationReportEditText = findViewById(R.id.ReportEditText);
        submitReportButton = findViewById(R.id.submitReportButton);

        // Handle the "Submit Report" button click
        submitReportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the patient's name and consultation report from the EditText fields
                String patientName = patientNameEditText.getText().toString();
                String report = consultationReportEditText.getText().toString();

                if (patientName.isEmpty() ||  report.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please fill in all the fields", Toast.LENGTH_SHORT).show();
                    return;
                } else {

                    SharedPreferences sharedPreferences = getSharedPreferences("DoctorPrefs", MODE_PRIVATE);
                    // Retrieve the data using the key
                    String doctorName = sharedPreferences.getString("doctorName", "");

                                      // Save doctor details to the Firebase Realtime Database
                    DatabaseReference doctorRef = databaseReference.child("doctorReport").push();
                    doctorRef.child("patientName").setValue(patientName);
                    doctorRef.child("consultationReport").setValue(report);
                   doctorRef.child("doctorName").setValue(doctorName);


                    Toast.makeText(getApplicationContext(), "Report Submitted successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SubmitConsultationReport.this, HomeScreenDoctor.class);
                    startActivity(intent);
                    finish();
                    // Redirect to the doctor's dashboard or main activity
                    // You can add code here to open the main activity for doctors
                // Handle the submission of the report, e.g., save it to a database
                // You can add your logic here.
            }
        }
    });
    }
}