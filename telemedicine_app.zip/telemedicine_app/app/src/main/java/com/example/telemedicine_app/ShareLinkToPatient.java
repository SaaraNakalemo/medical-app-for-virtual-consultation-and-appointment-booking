package com.example.telemedicine_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ShareLinkToPatient extends AppCompatActivity {

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");

    private EditText linkEditText, usernameEditText;
    private Button shareButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_link_to_patient);

        linkEditText = findViewById(R.id.linkEditText);
        usernameEditText = findViewById(R.id.usernameEditText);
        shareButton = findViewById(R.id.shareButton);

        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // You can implement the logic to share the link with the patient here
                // For example, you can store the link in Firebase Database under the patient's username

                // Once shared, you can navigate to a different activity or perform other actions
                // Here, we'll just display a message for demonstration purposes
                //String message = "Link shared with " + username;
             //   showToast(message);
                shareLinkDoctor();
            }
        });
    }




    // Helper method to show a toast message
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    private void shareLinkDoctor() {

        // Get the link and username entered by the doctor
        String link = linkEditText.getText().toString();
        String username = usernameEditText.getText().toString();


      if (link.isEmpty() ||  username.isEmpty()) {

            Toast.makeText(getApplicationContext(), "Please fill in all the fields", Toast.LENGTH_SHORT).show();
            return;
        } else {

          // Validate doctorName (letters only)
          if (!username.matches("^[a-zA-Z ]+$")) {
              Toast.makeText(getApplicationContext(), "Patient name can only contain letters and spaces", Toast.LENGTH_SHORT).show();
              return;
          }


          // progressbar.setVisibility(View.VISIBLE);
            // Save doctor details to the Firebase Realtime Database
            DatabaseReference doctorRef = databaseReference.child("shareLink").child(username);
            doctorRef.child("link").setValue(link);
            doctorRef.child("username").setValue(username);

            Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ShareLinkToPatient.this, VideoConferenceLinkDoctor.class);
            startActivity(intent);
            finish();
            // Redirect to the doctor's dashboard or main activity
            // You can add code here to open the main activity for doctors


        }
    }




    private void navigateToMainScreen() {

        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
        finish();
    }

}
