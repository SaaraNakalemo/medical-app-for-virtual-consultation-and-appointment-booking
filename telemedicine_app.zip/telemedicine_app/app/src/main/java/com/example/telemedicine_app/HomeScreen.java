package com.example.telemedicine_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.navigation.NavigationView;


public class HomeScreen extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private ActionBar actionBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        Button btn = findViewById(R.id.makeAppointmentButton);
        Button btnViewAppointments = findViewById(R.id.viewAppointments);

        //Navigation ui  codes
        Toolbar toolbar = findViewById(R.id.toolbar);
        // Set the initial title of the Toolbar
        toolbar.setTitle("Patient");
        setSupportActionBar(toolbar);
        // Get the ActionBar and enable the navigation drawer icon
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.icons_menu); // Replace with your icon resource
        }

        drawerLayout = findViewById(R.id.drawer_layout);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        // Inflate the header layout
        View headerView = navigationView.getHeaderView(0);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(HomeScreen.this, MakeAppointment.class);
                startActivity(intent);
                finish();
            }
        });

        btnViewAppointments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeScreen.this, PatientAppointment.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.nav_home) {
            Intent intent = new Intent(HomeScreen.this, HomeScreen.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
        } else if (itemId == R.id.nav_makeappointments) {
            Intent itemScreen = new Intent(HomeScreen.this, MakeAppointment.class);
            itemScreen.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(itemScreen);
        }  else if (itemId == R.id.nav_your_appointments) {

            Intent itemScreen = new Intent(HomeScreen.this, PatientAppointment.class);
            itemScreen.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(itemScreen);
             }else if (itemId == R.id.nav_join_video) {

            Intent itemScreen = new Intent(HomeScreen.this, patientViewVideLink.class);
            itemScreen.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(itemScreen);

        }else if (itemId == R.id.report_links) {

            Intent itemScreen = new Intent(HomeScreen.this, PatientReports.class);
            itemScreen.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(itemScreen);
        } else if (itemId == R.id.nav_sign_out) {
            clearUserDataFromSharedPreferences();
            navigateToLoginScreen();

        }

        // Close the drawer after handling the item
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    private void clearUserDataFromSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserData", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }

    private void navigateToLoginScreen() {
        Intent intent = new Intent(this, PatientLoginActivity.class);
        startActivity(intent);
        finish();
    }

}