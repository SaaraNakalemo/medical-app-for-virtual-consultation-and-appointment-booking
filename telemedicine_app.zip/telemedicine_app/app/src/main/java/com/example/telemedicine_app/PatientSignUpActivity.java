package com.example.telemedicine_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.security.PrivateKey;

public class PatientSignUpActivity extends AppCompatActivity {

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");

    private EditText userIdEditText, passwordEditText, phoneNumber;
    private TextView loginPatient, loginDoctor;
    private Button  signUP;
    private ProgressBar progressbar;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_sign_up);

        mAuth = FirebaseAuth.getInstance();
        //Userid can either phone number or username
        signUP = findViewById(R.id.Sign);
        userIdEditText = findViewById(R.id.patientEmail);
        phoneNumber = findViewById(R.id.PhoneNumber);
        loginPatient = findViewById(R.id.textViewLogin);
        loginDoctor  = findViewById(R.id.LoginDoctor);
        passwordEditText = findViewById(R.id.AccountPassword);
        progressbar = findViewById(R.id.progressbar);

        loginDoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PatientSignUpActivity.this, DoctorLogin.class);
                startActivity(intent);
                finish();
            }
        });

        loginPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(PatientSignUpActivity.this, PatientLoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
        signUP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerDoctor();

            }
        });


    }

    private void registerDoctor() {

        final String patientName = userIdEditText.getText().toString().trim();
        final String phoneNum =  phoneNumber.getText().toString().trim();
        final String password = passwordEditText.getText().toString().trim();

        if (patientName.isEmpty() || phoneNum.isEmpty()  || password.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please fill in all the fields", Toast.LENGTH_SHORT).show();
            return;
        } else {

            // Validate doctorName (letters only)
            if (!patientName.matches("^[a-zA-Z ]+$")) {
                Toast.makeText(getApplicationContext(), "Patient name can only contain letters and spaces", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate phoneNumber (numbers only)
            if (!phoneNum.matches("^[0-9]+$")) {
                Toast.makeText(getApplicationContext(), "Phone number can only contain numbers", Toast.LENGTH_SHORT).show();
                return;
            }

            progressbar.setVisibility(View.VISIBLE);

            // Save doctor details to the Firebase Realtime Database
            DatabaseReference doctorRef = databaseReference.child("patients").child(phoneNum);
            doctorRef.child("name").setValue(patientName);
            doctorRef.child("phoneNumber").setValue(phoneNum);
            doctorRef.child("password").setValue(password);

            Toast.makeText(getApplicationContext(), "Patient registration successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(PatientSignUpActivity.this, HomeScreen.class);
            startActivity(intent);
            finish();
            // Redirect to the doctor's dashboard or main activity
            // You can add code here to open the main activity for doctors
            savePatientName(phoneNum);

        }
    }

    private void savePatientName(String phoneNum) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserData", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("phoneNum", phoneNum);
        editor.apply();
    }



    private void navigateToMainScreen() {

        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
        finish();
    }

}