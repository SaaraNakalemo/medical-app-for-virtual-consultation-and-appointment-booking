package com.example.telemedicine_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class UpdateDeleteAppointment extends AppCompatActivity {

    private EditText updatePatientNameEditText;
    private EditText updateContactNumberEditText;
    private DatePicker updateDatePicker;
    private TimePicker updateTimePicker;
    private EditText updateAppointmentDescriptionEditText;
    private EditText updateSpecialityEditText;
    private Button updateAppointmentButton;
    private Button deleteAppointmentButton;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete_appointment);

        // Initialize UI components
        updatePatientNameEditText = findViewById(R.id.updatePatientNameEditText);
        updateContactNumberEditText = findViewById(R.id.updateContactNumberEditText);
        updateDatePicker = findViewById(R.id.updateDatePicker);
        updateTimePicker = findViewById(R.id.updateTimePicker);
        updateAppointmentDescriptionEditText = findViewById(R.id.updateAppointmentDescriptionEditText);
        updateSpecialityEditText = findViewById(R.id.updateSpecialityEditText);
        updateAppointmentButton = findViewById(R.id.updateAppointmentButton);
        deleteAppointmentButton = findViewById(R.id.deleteAppointmentButton);
        // Retrieve values from the Intent
        Intent intent = getIntent();
        if (intent != null) {
            String patientName = intent.getStringExtra("patientName");
            String contactNumber = intent.getStringExtra("contactNumber");
            String appointmentDescription = intent.getStringExtra("appointmentDescription");
            String time = intent.getStringExtra("preferredTime");
            // Set the retrieved values in the EditText fields
            updatePatientNameEditText.setText(patientName);
            updateContactNumberEditText.setText(contactNumber);
            updateAppointmentDescriptionEditText.setText(appointmentDescription);







            updateAppointmentButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    int year = updateDatePicker.getYear();
                    int month = updateDatePicker.getMonth() + 1; // Month is zero-based, so add 1
                    int day = updateDatePicker.getDayOfMonth();
                    String selectedDate = year + "-" + month + "-" + day;

                    int hour = updateTimePicker.getHour();
                    int minute = updateTimePicker.getMinute();
                    String selectedTime = hour + ":" + minute;
                    String UpdatePatientName = updatePatientNameEditText.getText().toString();
                    String UpdateContact =    updateContactNumberEditText.getText().toString();
                    String updateAppointmentDescription =   updateAppointmentDescriptionEditText.getText().toString();
                    // Retrieve and set other details in a similar manner
                    String selectedSpeciality = updateSpecialityEditText.getText().toString();
                    // Log the values to help with debugging
                    Log.d("UpdateDeleteAppointment", "Updated Patient Name: " + UpdatePatientName);
                    Log.d("UpdateDeleteAppointment", "Updated Contact Number: " + UpdateContact);
                    Log.d("UpdateDeleteAppointment", "Updated Appointment Description: " + updateAppointmentDescription);
                    Log.d("UpdateDeleteAppointment", "Selected Time: " + selectedTime);
                    Log.d("UpdateDeleteAppointment", "Selected Speciality: " + selectedSpeciality);
                    Log.d("UpdateDeleteAppointment", "Selected Date: " + selectedDate);

                    if (TextUtils.isEmpty(UpdatePatientName) || TextUtils.isEmpty(UpdateContact) || TextUtils.isEmpty(updateAppointmentDescription) ||
                            TextUtils.isEmpty(selectedTime) || TextUtils.isEmpty(selectedSpeciality) || TextUtils.isEmpty(selectedDate)) {
                        // Display an error message or Toast if any required fields are empty
                        Toast.makeText(UpdateDeleteAppointment.this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                    } else {

                        // Update the appointment data based on the patient's name
                        DatabaseReference appointmentsRef = FirebaseDatabase.getInstance().getReference("appointments");
                        Query query = appointmentsRef.orderByChild("preferredTime").equalTo(time);
                        query.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot appointmentSnapshot : dataSnapshot.getChildren()) {
                                    String appointmentId = appointmentSnapshot.getKey();

                                    // Construct the appointment data to be updated
                                    Map<String, Object> updatedAppointmentData = new HashMap<>();
                                    updatedAppointmentData.put("patientName", UpdatePatientName);
                                    updatedAppointmentData.put("contactNumber", UpdateContact);
                                    updatedAppointmentData.put("appointmentDescription", updateAppointmentDescription);
                                    updatedAppointmentData.put("preferredTime", selectedTime);
                                    updatedAppointmentData.put("selectedSpeciality", selectedSpeciality);
                                    updatedAppointmentData.put("preferredDate", selectedDate);
                                    // Add other updated details to the map

                                    // Update the appointment data in the Firebase Realtime Database
                                    appointmentsRef.child(appointmentId).updateChildren(updatedAppointmentData);
                                }

                                // Display a success message or perform other actions
                                Toast.makeText(UpdateDeleteAppointment.this, "Appointments updated successfully", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });


                    }

                }

            });

            deleteAppointmentButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    int year = updateDatePicker.getYear();
                    int month = updateDatePicker.getMonth() + 1; // Month is zero-based, so add 1
                    int day = updateDatePicker.getDayOfMonth();
                    String selectedDate = year + "-" + month + "-" + day;

                    int hour = updateTimePicker.getHour();
                    int minute = updateTimePicker.getMinute();
                    String selectedTime = hour + ":" + minute;
                    String UpdatePatientName = updatePatientNameEditText.getText().toString();
                    String UpdateContact =    updateContactNumberEditText.getText().toString();
                    String updateAppointmentDescription =   updateAppointmentDescriptionEditText.getText().toString();
                    // Retrieve and set other details in a similar manner
                    String selectedSpeciality = updateSpecialityEditText.getText().toString();
                    // Log the values to help with debugging
                    Log.d("UpdateDeleteAppointment", "Updated Patient Name: " + UpdatePatientName);
                    Log.d("UpdateDeleteAppointment", "Updated Contact Number: " + UpdateContact);
                    Log.d("UpdateDeleteAppointment", "Updated Appointment Description: " + updateAppointmentDescription);
                    Log.d("UpdateDeleteAppointment", "Selected Time: " + selectedTime);
                    Log.d("UpdateDeleteAppointment", "Selected Speciality: " + selectedSpeciality);
                    Log.d("UpdateDeleteAppointment", "Selected Date: " + selectedDate);


                        // Delete the appointment based on the preferredDate
                        DatabaseReference appointmentsRef = FirebaseDatabase.getInstance().getReference("appointments");
                    Query query = appointmentsRef.orderByChild("preferredTime").equalTo(time);


                    query.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot appointmentSnapshot : dataSnapshot.getChildren()) {
                                    String appointmentId = appointmentSnapshot.getKey();

                                    // Delete the appointment from the Firebase Realtime Database
                                    appointmentsRef.child(appointmentId).removeValue();
                                }

                                // Display a success message or perform other actions
                                Toast.makeText(UpdateDeleteAppointment.this, "Appointment deleted successfully", Toast.LENGTH_SHORT).show();

                                // Close the activity or navigate back to the previous screen
                                finish();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                // Handle error
                            }
                        });
                    }

            });
        }



    }
}