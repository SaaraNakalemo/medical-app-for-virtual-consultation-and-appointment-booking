package com.example.telemedicine_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.View;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class VideoConferenceLinkDoctor extends AppCompatActivity {

    private ListView linkListView;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_conference_link_doctor);
        databaseReference = FirebaseDatabase.getInstance().getReference("shareLink");

        // Initialize ListView
        linkListView = findViewById(R.id.LinksListView);
        SharedPreferences sharedPreferences = getSharedPreferences("DoctorPrefs", MODE_PRIVATE);
        // Retrieve the data using the key
        String doctorName = sharedPreferences.getString("doctorName", "");
        // Query for appointments with selectedSpeciality = "General Practitioner"
        Query query = databaseReference.orderByChild("doctorname").equalTo(doctorName);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<String> videoLinkList = new ArrayList<>();
                for (DataSnapshot linkSnapshot : dataSnapshot.getChildren()) {
                    Map<String, Object> linkData = (Map<String, Object>)linkSnapshot.getValue();

                    // Check if appointment data is not null
                    if (linkData!= null) {
                        String patientName = "Patient Name: " + linkData.get("username");
                        final String videoLink = "Link: " + linkData.get("link").toString(); // Modify the format here


                        // Find the TextView elements in your layout
                        TextView patientNameTextView = findViewById(R.id.patientNameTextView);
                        TextView videoLinkTextView = findViewById(R.id.videoLinkTextView);

                        // Set patient name in the respective TextView
                        patientNameTextView.setText(patientName);
                        videoLinkTextView.setText(videoLink);

                        // Set an onClickListener to handle the video link click
                        videoLinkTextView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Handle the click event for the video link
                                openVideoLinkInWebView(videoLink);
                            }
                        });                   }
                }

                // Create the adapter to populate the ListView
            //    ArrayAdapter<String> adapter = new ArrayAdapter<>(
              //          VideoConferenceLinkDoctor.this,
                //        android.R.layout.simple_list_item_1,
                  //      videoLinkList
                //);

                // Set the adapter for the ListView
              //  linkListView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
                //  Log.e(TAG, "Database Error: " + databaseError.getMessage());
            }
        });
    }

    private void openVideoLinkInWebView(String url) {
        // Find the WebView in your layout
        WebView webView = findViewById(R.id.webView);

        // Load the URL in the WebView
        webView.getSettings().setJavaScriptEnabled(true); // Enable JavaScript if needed
        webView.loadUrl(url);
    }
}