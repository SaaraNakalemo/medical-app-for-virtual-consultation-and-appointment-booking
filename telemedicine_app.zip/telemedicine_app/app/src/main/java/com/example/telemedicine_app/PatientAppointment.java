package com.example.telemedicine_app;

import static androidx.fragment.app.FragmentManager.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PatientAppointment extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    List<String> appointmentsList = new ArrayList<>();
    private ListView appointmentsListView;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_appointment);

        ImageView backIcon = findViewById(R.id.back_icon);



        SharedPreferences sharedPreferences = getSharedPreferences("PatientPrefs", MODE_PRIVATE);
// Retrieve the data using the key
        String patientName = sharedPreferences.getString("name", "");

        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click event here
                // Perform the desired action when the back icon is clicked
                // For example, you can start a new activity to navigate back
                Intent intent = new Intent(PatientAppointment.this, HomeScreen.class);
                startActivity(intent);
                finish();
            }
        });
        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();  // Initialize Firebase Authentication
        currentUser = mAuth.getCurrentUser(); // Get the current logged-in user
        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com"); // Initialize the Firebase Realtime Database

        // Initialize your ListView
        appointmentsListView = findViewById(R.id.appointmentsListView);




        // Initialize Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("appointments");

        // Initialize ListView
        appointmentsListView = findViewById(R.id.appointmentsListView);

        // Query for appointments with selectedSpeciality = "General Practitioner"
        Query query = databaseReference.orderByChild("patientName").equalTo(patientName);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot appointmentSnapshot : dataSnapshot.getChildren()) {
                    Map<String, Object> appointmentData = (Map<String, Object>) appointmentSnapshot.getValue();

                    // Check if appointment data is not null
                    if (appointmentData != null) {
                        String appointmentDetails = "Patient Name: " + appointmentData.get("patientName") + "\n" +
                                "Contact Number: " + appointmentData.get("contactNumber") + "\n" +
                                "Appointment Date: " + appointmentData.get("preferredDate") + "\n" +
                                "Appointment Time: " + appointmentData.get("preferredTime") + "\n" +
                                "Reason for appointment: " + appointmentData.get("appointmentDescription") + "\n" +
                        "Speciality: " + appointmentData.get("selectedSpeciality");

                        appointmentsList.add(appointmentDetails);
                    }
                }

                // Create the adapter to populate the ListView
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        PatientAppointment.this,
                        android.R.layout.simple_list_item_1,
                        appointmentsList
                );

                // Set the adapter for the ListView
                appointmentsListView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
               // Log.e(TAG, "Database Error: " + databaseError.getMessage());
            }
        });

        appointmentsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                // Retrieve the appointment details for the selected item
                String selectedAppointmentDetails = appointmentsList.get(position);

                // Split the appointmentDetails to extract the details you need
                String[] detailsArray = selectedAppointmentDetails.split("\n");
                String patientName = detailsArray[0].substring("Patient Name: ".length());
                String contactNumber = detailsArray[1].substring("Contact Number: ".length());
                String preferredDate = detailsArray[2].substring("Appointment Date: ".length());
                String preferredTime = detailsArray[3].substring("Appointment Time: ".length());
                String appointmentDescription = detailsArray[4].substring("Reason for appointment: ".length());
                String selectedSpeciality = detailsArray[5].substring("Speciality: ".length());

                // Create an intent to open the UpdateDeleteAppointment activity
                Intent updateIntent = new Intent(PatientAppointment.this, UpdateDeleteAppointment.class);

                // Pass the extracted appointment details to the intent
                updateIntent.putExtra("patientName", patientName);
                updateIntent.putExtra("contactNumber", contactNumber);
                updateIntent.putExtra("preferredTime", preferredTime);
                updateIntent.putExtra("appointmentDescription", appointmentDescription);
                updateIntent.putExtra("position", position); // Pass the position for future reference

                // Start the UpdateDeleteAppointment activity
                startActivity(updateIntent);
            }
        });


    }


}