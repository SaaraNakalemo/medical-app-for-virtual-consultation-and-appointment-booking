package com.example.telemedicine_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PatientLoginActivity extends AppCompatActivity {

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");

    private EditText phoneEditText;
    private EditText passwordEditText;

    private TextView signupPatient, loginDoctor;
    private ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);
        loginDoctor   = findViewById(R.id.LoginDoctor);
        signupPatient  = findViewById(R.id.textViewLogin);

        phoneEditText = findViewById(R.id.patientName);
        passwordEditText = findViewById(R.id.AccountPassword);
        progressBar = findViewById(R.id.progressbar);

        signupPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PatientLoginActivity.this, PatientSignUpActivity.class);
                startActivity(intent);
                finish();
            }
        });

        loginDoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(PatientLoginActivity.this, DoctorLogin.class);
                startActivity(intent);
                finish();
            }
        });

        Button loginButton = findViewById(R.id.Login);
        //TextView signUpTextView = findViewById(R.id.SignUpDoctor);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                login();
            }
        });

      /*  SignUpDoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(DoctorLogin.this, DoctorSignUp.class);
                startActivity(intent);
                finish();
            }
        });*/

    }


    private void login() {
        String phoneNumber = phoneEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (phoneNumber.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
            return;
        } else {

            // Validate phoneNumber (numbers only)
            if (!phoneNumber.matches("^[0-9]+$")) {
                Toast.makeText(getApplicationContext(), "Phone number can only contain numbers", Toast.LENGTH_SHORT).show();
                return;
            }
            databaseReference.child("patients").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    if(snapshot.hasChild(phoneNumber)){

                        String getPassword =  snapshot.child(phoneNumber).child("password").getValue(String.class);
                        String getName =  snapshot.child(phoneNumber).child("name").getValue(String.class);
                        // Save the speciality to SharedPreferences
                        SharedPreferences sharedPreferences = getSharedPreferences("PatientPrefs", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("name", getName);
                        editor.apply();
                        if(getPassword.equals(password)){

                            Toast.makeText(PatientLoginActivity.this, "Successfully Logged In", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(PatientLoginActivity.this, HomeScreen.class));
                            finish();
                        }else{

                            Toast.makeText(PatientLoginActivity.this, "Password or phone number wrong", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
    }
}