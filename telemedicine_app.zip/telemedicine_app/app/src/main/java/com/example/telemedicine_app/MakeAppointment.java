package com.example.telemedicine_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MakeAppointment extends AppCompatActivity {

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_appointment);
        // Inside your activity or fragment



        // Get a reference to the Spinner
        Spinner specialitySpinner = findViewById(R.id.specialitySpinner);

// Create an ArrayAdapter using the string array and a default Spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.medical_specialities, android.R.layout.simple_spinner_item);

// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

// Apply the adapter to the Spinner
        specialitySpinner.setAdapter(adapter);

        // Get references to your EditText fields and other UI elements
        EditText patientNameEditText = findViewById(R.id.patientName);
        EditText contactNumberEditText = findViewById(R.id.contactNumber);
        EditText appointmentDescriptionEditText = findViewById(R.id.appointmentDescription);
        DatePicker datePicker = findViewById(R.id.preferredDate);
        TimePicker timePicker = findViewById(R.id.preferredTime);
        Button makeAppointmentButton = findViewById(R.id.makeAppointmentButton);
        ImageView backIcon = findViewById(R.id.back_icon);

        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click event here
                // Perform the desired action when the back icon is clicked
                // For example, you can start a new activity to navigate back
                Intent intent = new Intent(MakeAppointment.this, HomeScreen.class);
                startActivity(intent);
                finish();
            }
        });


        makeAppointmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get text input from EditText fields
                String patientName = patientNameEditText.getText().toString();
                String contactNumber = contactNumberEditText.getText().toString();
                String appointmentDescription = appointmentDescriptionEditText.getText().toString();
                // Get the selected speciality
                String selectedSpeciality = specialitySpinner.getSelectedItem().toString();

                // Check if any of the required fields are empty
                if (TextUtils.isEmpty(patientName) || TextUtils.isEmpty(contactNumber) || TextUtils.isEmpty(appointmentDescription)) {
                    // Display an error message or Toast to inform the user to fill in all required fields.
                    Toast.makeText(getApplicationContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                } else {

                    // Validate doctorName (letters only)
                    if (!patientName.matches("^[a-zA-Z ]+$")) {
                        Toast.makeText(getApplicationContext(), "Patient name can only contain letters and spaces", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Validate phoneNumber (numbers only)
                    if (!contactNumber.matches("^[0-9]+$")) {
                        Toast.makeText(getApplicationContext(), "Phone number can only contain numbers", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    // Get the selected date from the DatePicker
                    int year = datePicker.getYear();
                    int month = datePicker.getMonth() + 1; // Month is zero-based, so add 1
                    int day = datePicker.getDayOfMonth();
                    String preferredDate = year + "-" + month + "-" + day;

                    // Get the selected time from the TimePicker
                    int hour = timePicker.getHour();
                    int minute = timePicker.getMinute();
                    String preferredTime = hour + ":" + minute;
                    DatabaseReference userAppointmentsRef = databaseReference.child("appointments").push();

                    // Save the appointment data directly to the database.
                    userAppointmentsRef.child("patientName").setValue(patientName);
                    userAppointmentsRef.child("contactNumber").setValue(contactNumber);
                    userAppointmentsRef.child("appointmentDescription").setValue(appointmentDescription);
                    userAppointmentsRef.child("preferredDate").setValue(preferredDate);
                    userAppointmentsRef.child("preferredTime").setValue(preferredTime);
                    userAppointmentsRef.child("selectedSpeciality").setValue(selectedSpeciality);

                    Toast.makeText(getApplicationContext(), "Appointment saved!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MakeAppointment.this, PatientAppointment.class);
                    startActivity(intent);
                    finish();


                }
            }
        });
    }

    private void saveAppointmentData(String patientName, String contactNumber, String appointmentDescription, String preferredDate, String preferredTime, String selectedSpeciality) {




    }
}