package com.example.telemedicine_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DoctorSignUp extends AppCompatActivity {
    private FirebaseAuth mAuth;

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://telemedicineapp-60558-default-rtdb.firebaseio.com");

    private EditText doctorNameEditText;
    private EditText phoneNumberEditText;
    private Spinner specialitySpinner;
    private EditText passwordEditText;
    private Button signupButton;
    private TextView loginTextView;
    private ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_sign_up);

        // Get a reference to the Spinner
       specialitySpinner = findViewById(R.id.specialitySpinner);

// Create an ArrayAdapter using the string array and a default Spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.medical_specialities, android.R.layout.simple_spinner_item);

// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

// Apply the adapter to the Spinner
        specialitySpinner.setAdapter(adapter);
        // Initialize Firebase Authentication
        mAuth = FirebaseAuth.getInstance();

        // Get a reference to your Firebase Realtime Database
        databaseReference = FirebaseDatabase.getInstance().getReference();

        doctorNameEditText = findViewById(R.id.doctorName);
        phoneNumberEditText = findViewById(R.id.phoneNumber);
        passwordEditText = findViewById(R.id.AccountPassword);
        signupButton = findViewById(R.id.SignUp);
        loginTextView = findViewById(R.id.LoginDoctor);
        progressBar = findViewById(R.id.progressbar);

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerDoctor();
            }
        });

        loginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to the doctor login activity
                // You can add code here to open the login activity for doctors
            }
        });

    }

    private void registerDoctor() {
        final String doctorName = doctorNameEditText.getText().toString().trim();
        final String phoneNumber = phoneNumberEditText.getText().toString().trim();
        final String speciality = specialitySpinner.getSelectedItem().toString();
        final String password = passwordEditText.getText().toString().trim();

        if (doctorName.isEmpty() || phoneNumber.isEmpty() || speciality.isEmpty() || password.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please fill in all the fields", Toast.LENGTH_SHORT).show();
            return;
        } else {

            // Validate doctorName (letters only)
            if (!doctorName.matches("^[a-zA-Z ]+$")) {
                Toast.makeText(getApplicationContext(), "Doctor name can only contain letters and spaces", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate phoneNumber (numbers only)
            if (!phoneNumber.matches("^[0-9]+$")) {
                Toast.makeText(getApplicationContext(), "Phone number can only contain numbers", Toast.LENGTH_SHORT).show();
                return;
            }
            progressBar.setVisibility(View.VISIBLE);


            // Save doctor details to the Firebase Realtime Database
            DatabaseReference doctorRef = databaseReference.child("doctors").child(phoneNumber);
            doctorRef.child("name").setValue(doctorName);
            doctorRef.child("phoneNumber").setValue(phoneNumber);
            doctorRef.child("speciality").setValue(speciality);
            doctorRef.child("password").setValue(password);

            Toast.makeText(getApplicationContext(), "Doctor registration successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(DoctorSignUp.this, HomeScreenDoctor.class);
            startActivity(intent);
            finish();
            // Redirect to the doctor's dashboard or main activity
            // You can add code here to open the main activity for doctors


        }
    }




}
